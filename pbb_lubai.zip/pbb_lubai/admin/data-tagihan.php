<?php
session_start();
if (isset($_SESSION['sudahloginadmin']) && $_SESSION['sudahloginadmin'] == true && $_SESSION['nama_admin'] != "") {
    if (!isset($_GET['nop'])) {
        header("Location: daftar-tagihan.php");
        exit;
    }

    include("../libs/koneksi.php");
    $link = koneksi_db();

    $nop = trim($_GET['nop']);

    // Ambil data tagihan dari tabel tagihan
    $sql_tagihan = "SELECT * FROM tagihan WHERE nop = '$nop' ORDER BY tahun_pajak DESC";
    $res_tagihan = mysqli_query($link, $sql_tagihan);

    $jumlah_data = $res_tagihan ? mysqli_num_rows($res_tagihan) : 0;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Tagihan</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Data Tagihan</h2>
    <p><strong>NOP:</strong> <?= htmlspecialchars($nop) ?></p>
    <p><strong>Nama Wajib Pajak:</strong> Tidak Tersedia</p>
    <p><em>(Ditemukan <?= $jumlah_data ?> data tagihan untuk NOP ini)</em></p>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tahun Pajak</th>
                <th>Pokok</th>
                <th>Denda</th>
                <th>Jumlah</th>
                <th>Jatuh Tempo</th>
                <th>Jumlah Bulan</th>
                <th>Status</th>
                <th>Hapus</th>
            </tr>
        </thead>
        <tbody>
        <?php if ($res_tagihan && $jumlah_data > 0): ?>
            <?php while($row = mysqli_fetch_assoc($res_tagihan)): ?>
                <tr>
                    <td><?= $row['tahun_pajak'] ?></td>
                    <td>Rp <?= number_format($row['pokok'], 0, ',', '.') ?></td>
                    <td>Rp <?= number_format($row['denda'], 0, ',', '.') ?></td>
                    <td>Rp <?= number_format($row['jumlah_tagihan'], 0, ',', '.') ?></td>
                    <td><?= date('d-M-Y', strtotime($row['tgl_jatuh_tempo'])) ?></td>
                    <td><?= $row['jumlah_bulan'] ?></td>
                    <td><?= $row['status_kelunasan'] ?></td>
                    <td><a href="../libs/hapus-tagihan.php?id_tagihan=<?= $row['id_tagihan'] ?>&nop=<?= urlencode($nop) ?>"
   onclick="return confirm('Hapus tagihan ini?')">Hapus</a> </td>

                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="8" align="center">Tidak ada data tagihan untuk NOP ini</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    <a href="daftar-tagihan.php" class="btn btn-secondary">Kembali</a>
</div>
</body>
</html>
<?php
} else {
    header("Location: login.php");
    exit;
}
?>
