<?php
session_start();
if (isset($_SESSION['sudahloginadmin']) && $_SESSION['sudahloginadmin'] == true && $_SESSION['nama_admin'] != "") {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("../libs/koneksi.php"); ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Disyanjak Kec Lubai - Daftar Tagihan</title>

    <!-- Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/animate.min.css" rel="stylesheet">
    <link href="../css/prettyPhoto.css" rel="stylesheet">
    <link href="../css/main.css" rel="stylesheet">
    <link href="../css/responsive.css" rel="stylesheet">
    <link rel="shortcut icon" href="../images/ico/bdg.png">
</head>

<body class="homepage">
<header id="header">
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Daftar Pengajuan</a></li>
                    <li><a href="daftar-objek-pajak.php">Objek Pajak</a></li>
                    <li><a href="daftar-subjek-pajak.php">Subjek Pajak</a></li>
                    <li class="active dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Tagihan<i class="fa fa-angle-down" style="padding-left:8px;"></i></a>
                        <ul class="dropdown-menu">
                            <li class="active"><a href="#">Daftar Tagihan</a></li>
                            <li><a href="tambah-tagihan.php">Tambah Tagihan</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Admin<i class="fa fa-angle-down" style="padding-left:8px;"></i></a>
                        <ul class="dropdown-menu">
                            <li><a href="daftar-admin.php">Daftar Admin</a></li>
                            <li><a href="tambah-admin.php">Tambah Admin</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['nama_admin']; ?><i class="fa"><img src="../images/user.png" alt="" style="width:20px;height:20px;margin-left:15px; margin-bottom:4px;"></i></a>
                        <ul class="dropdown-menu">
                            <li><a href="ubah-admin.php?nip=<?php echo $_SESSION['nip']; ?>">Ubah Profil</a></li>
                            <li><a href="../libs/logout-admin.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>

<section id="contact-page">
    <div class="container" style="min-height:420px;">
        <div class="center">
            <h2>Daftar Tagihan</h2>
            <p class="lead">Pajak Bumi dan Bangunan</p>
        </div>
        <div class="row contact-wrap">
            <div class="col-sm-10"></div>
            <div class="col-sm-2">
                <label>Cari</label>
                <input type="search" id="search" name="search" placeholder="NOP" class="form-control" maxlength="18" onkeyup="search()">
            </div>
        </div>
        <div id="hasil" class="row contact-wrap">
            <!-- Data akan dimuat dari AJAX -->
        </div>
    </div>
</section>

<footer id="footer" class="midnight-blue">
    <div class="container text-center">
        &copy; 2016 Pajak Bumi Bangunan
    </div>
</footer>

<script src="../js/jquery.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.prettyPhoto.js"></script>
<script src="../js/jquery.isotope.min.js"></script>
<script src="../js/main.js"></script>
<script src="../js/wow.min.js"></script>
<script>
function search() {
    var nop = document.getElementById("search").value;
    var xmlhttp;

    if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest();
    } else {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            document.getElementById("hasil").innerHTML = xmlhttp.responseText;
        }
    };
    xmlhttp.open("GET", "../libs/cari-tagihan.php?nop=" + encodeURIComponent(nop), true);
    xmlhttp.send();
}

// Muat semua data saat pertama kali halaman dibuka
document.addEventListener("DOMContentLoaded", function () {
    search();
});
</script>
</body>
</html>
<?php
} else {
    header("Location: login.php");
    exit;
}
?>
