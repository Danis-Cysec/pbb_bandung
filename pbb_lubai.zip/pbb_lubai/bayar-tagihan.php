<?php
session_start();
if(($_SESSION['sudahlogin']==true)&&($_SESSION['ktp_user']!="")){
    include "libs/koneksi.php";
    $link = koneksi_db();

    $nop = isset($_GET['nop']) ? $_GET['nop'] : '';
    $success = isset($_GET['success']) ? $_GET['success'] : '';
    $error = isset($_GET['error']) ? $_GET['error'] : '';
    $msg = isset($_GET['msg']) ? $_GET['msg'] : '';

    // Ambil nik dari session
    $nik = $_SESSION['ktp_user'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Disyanjak Kec Lubai</title>

    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link rel="shortcut icon" href="images/ico/bdg.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/bdg.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/bdg.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/bdg.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/bdg.png">
</head>

<body class="homepage">
<header id="header">
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="collapse navbar-collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Beranda</a></li>
                    <li><a href="tentang.php">Tentang SIPP</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Portal Informasi Publik <i class="fa fa-angle-down" style="padding-left:8px;"></i></a>
                        <ul class="dropdown-menu">
                            <li><a href="cari-data-pbb.php">Pencarian Data PBB</a></li>
                            <li><a href="cek-njop.php">Cek NJOP PBB</a></li>
                        </ul>
                    </li>
                    <li class="active dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Pelayanan PBB Online<i class="fa fa-angle-down" style="padding-left:8px;"></i></a>
                        <ul class="dropdown-menu">
                            <li><a href="daftar-op.php">Pendaftaran Objek Pajak</a></li>
                            <li class="active"><a href="#">Pembayaran Tagihan PBB</a></li>
                        </ul>
                    </li>
                    <li class=" dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['nama_user'];?><i class="fa"><img src="images/user.png" alt="" style="width:20px;height:20px;margin-left:15px; margin-bottom:4px;"></i></a>
                        <ul class="dropdown-menu">
                            <li><a href="ubah-profil.php">Ubah Profil</a></li>
                            <li><a href="libs/logout-user.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>

<section id="contact-page">
    <div class="container" style="min-height:420px;">
        <div class="center">
            <h2>Pembayaran Tagihan</h2>
            <p class="lead">Pajak Bumi dan Bangunan</p>
        </div>

        <?php if($success): ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Berhasil!</strong> <?php echo htmlspecialchars($msg); ?>
                <br><small>Silakan menunggu verifikasi dari admin.</small>
            </div>
        <?php endif; ?>

        <?php if($error): ?>
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Error!</strong> <?php echo htmlspecialchars($msg); ?>
            </div>
        <?php endif; ?>

        <div class="row contact-wrap">
            <form class="contact-form" name="contact-form" method="post" action="libs/bayar-tagihan.php" enctype="multipart/form-data">
                <div class="col-sm-12">
                    <div class="col-sm-4 col-sm-offset-2">
                        <div class="form-group">
                            <label>Nomor Objek Pajak *</label>
                            <input type="text" name="nop" class="form-control left" required maxlength="18" onkeypress="return event.charCode >= 48 && event.charCode <= 57" value="<?php echo htmlspecialchars($nop); ?>"> 
                        </div>
                        <div class="form-group">
                            <label>Tahun Tagihan Objek Pajak *</label>
                            <input type="text" name="tahun_pajak" class="form-control left" required maxlength="4" onkeypress="return event.charCode >= 48 && event.charCode <= 57"> 
                        </div>           
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label>Nama Bank *</label>
                            <select name="nama_bank" class="form-control left" required>
                                <option value="" disabled selected>Pilih Bank</option>
                                <option value="Bank CIMB Niaga">Bank CIMB Niaga</option>
                                <option value="Bank Central Asia (BCA)">Bank Central Asia (BCA)</option>
                                <option value="Bank Mandiri">Bank Mandiri</option>
                                <option value="Bank Negara Indonesia (BNI)">Bank Negara Indonesia (BNI)</option>
                                <option value="Bank Rakyat Indonesia (BRI)">Bank Rakyat Indonesia (BRI)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Nomor Rekening *</label>
                            <input type="text" name="no_rekening" class="form-control left" required onkeypress="return event.charCode >= 48 && event.charCode <= 57"> 
                        </div>
                        <div class="form-group">
                            <label>Nama Pemilik Rekening *</label>
                            <input type="text" name="pemilik_rekening" class="form-control left" required onkeypress="return (event.charCode >= 65 && event.charCode <= 90) || (event.charCode >= 97 && event.charCode <= 122) || event.charCode == 32"> 
                        </div>
                        <div class="form-group">
                            <label>Tanggal Pembayaran *</label>
                            <input type="date" name="tanggal_bayar" class="form-control" required> 
                        </div>
                        <div class="form-group">
                            <label>Bukti Pembayaran *</label>
                            <input type="file" id="bukti" name="bukti" class="form-control left" required> 
                        </div>
                    </div>
                </div>

                <!-- Kirim NIK dari session ke proses -->
                <input type="hidden" name="nik" value="<?php echo htmlspecialchars($nik); ?>">

                <div class="form-group" style="float:right;">
                    <button type="submit" name="submit" class="btn btn-primary btn-lg" required="required">Submit</button>
                </div>
            </form> 
        </div>
    </div>
</section>

<footer id="footer" class="midnight-blue">
    <div class="container text-center">
        &copy; 2016 <a target="_blank">Pajak Bumi Bangunan</a>.
    </div>
</footer>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/main.js"></script>
<script src="js/wow.min.js"></script>
<script>
setTimeout(function() {
    $('.alert').fadeTo(500, 0).slideUp(500, function(){
        $(this).remove(); 
    });
}, 5000);
</script>
</body>
</html>
<?php
}
else {
    header("Location: login.php");
    exit;
}
?>
