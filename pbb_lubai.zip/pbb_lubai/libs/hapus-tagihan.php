<?php 
include("koneksi.php");

if (isset($_GET['id_tagihan']) && isset($_GET['nop'])) {
    $id_tagihan = intval($_GET['id_tagihan']); // pastikan integer
    $nop = trim($_GET['nop']);

    $link = koneksi_db();

    $sql = "DELETE FROM tagihan WHERE id_tagihan = ?";
    $stmt = mysqli_prepare($link, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id_tagihan);

    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Data tagihan berhasil dihapus');</script>";
    } else {
        echo "<script>alert('Gagal menghapus data: " . mysqli_error($link) . "');</script>";
    }

    mysqli_stmt_close($stmt);
    mysqli_close($link);

    echo "<script>window.location.href = '../admin/data-tagihan.php?nop=" . urlencode($nop) . "';</script>";
} else {
    echo "<script>alert('Parameter tidak lengkap.'); window.location.href = '../admin/daftar-tagihan.php';</script>";
}
?>
