<?php
include("koneksi.php");
$link = koneksi_db();

$hasil = "";

if (isset($_GET['nop'])) {
    $nop = trim($_GET['nop']);
    $sql = "SELECT * FROM tagihan WHERE nop LIKE '%$nop%' ORDER BY nop, tahun_pajak DESC";
    $res = mysqli_query($link, $sql);

    if ($res && mysqli_num_rows($res) > 0) {
        $hasil .= "<div class='table-responsive'><table class='table table-bordered'>";
        $hasil .= "<thead>
                    <tr>
                        <th>NOP</th>
                        <th>Tahun Pajak</th>
                        <th>Pokok</th>
                        <th>Denda</th>
                        <th>Jumlah</th>
                        <th>Jatuh Tempo</th>
                        <th>Bulan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                   </thead><tbody>";

        while ($row = mysqli_fetch_assoc($res)) {
            $hasil .= "<tr>";
            $hasil .= "<td>" . htmlspecialchars($row['nop']) . "</td>";
            $hasil .= "<td>" . $row['tahun_pajak'] . "</td>";
            $hasil .= "<td>Rp " . number_format($row['pokok'], 0, ',', '.') . "</td>";
            $hasil .= "<td>Rp " . number_format($row['denda'], 0, ',', '.') . "</td>";
            $hasil .= "<td>Rp " . number_format($row['jumlah_tagihan'], 0, ',', '.') . "</td>";
            $hasil .= "<td>" . date('d-m-Y', strtotime($row['tgl_jatuh_tempo'])) . "</td>";
            $hasil .= "<td>" . $row['jumlah_bulan'] . "</td>";
            $hasil .= "<td>" . $row['status_kelunasan'] . "</td>";
            $hasil .= "<td><a href='../admin/data-tagihan.php?nop=" . urlencode($row['nop']) . "' class='btn btn-sm btn-primary'>Detail</a></td>";
            $hasil .= "</tr>";
        }

        $hasil .= "</tbody></table></div>";
    } else {
        $hasil .= "<p>Tidak ada data tagihan ditemukan untuk NOP ini.</p>";
    }
}

echo $hasil;
?>
