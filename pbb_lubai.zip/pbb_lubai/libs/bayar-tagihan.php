<?php
session_start();
if (!isset($_SESSION['sudahlogin']) || $_SESSION['sudahlogin'] !== true || !isset($_SESSION['ktp_user'])) {
    header("Location: ../login.php");
    exit();
}

include "koneksi.php";
$link = koneksi_db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nop = isset($_POST['nop']) ? $_POST['nop'] : '';
    $tahun = isset($_POST['tahun_pajak']) ? $_POST['tahun_pajak'] : '';
    $nik = $_SESSION['ktp_user'];

    if ($nop === '' || $tahun === '') {
        header("Location: ../bayar-tagihan.php?error=missing&msg=Data tidak lengkap&nop=" . urlencode($nop));
        exit();
    }

    // Siapkan statement update
    $query = "UPDATE tagihan SET status_kelunasan = 'Lunas', id_pembayaran = ? WHERE nop = ? AND tahun_pajak = ? AND status_kelunasan = 'Belum Lunas'";
    $stmt = mysqli_prepare($link, $query);

    if ($stmt) {
        $id_pembayaran = rand(100000, 999999); // Simulasi ID Pembayaran
        mysqli_stmt_bind_param($stmt, "iss", $id_pembayaran, $nop, $tahun);

        if (mysqli_stmt_execute($stmt)) {
            header("Location: ../bayar-tagihan.php?success=1&msg=Tagihan berhasil dibayar&nop=" . urlencode($nop));
            exit();
        } else {
            header("Location: ../bayar-tagihan.php?error=execute&msg=Gagal membayar tagihan&nop=" . urlencode($nop));
            exit();
        }
    } else {
        header("Location: ../bayar-tagihan.php?error=stmt&msg=Gagal menyiapkan query&nop=" . urlencode($nop));
        exit();
    }
} else {
    header("Location: ../bayar-tagihan.php?error=invalid&msg=Metode tidak diizinkan");
    exit();
}
?>