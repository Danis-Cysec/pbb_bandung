<?php
include("koneksi.php");
$link = koneksi_db();

$nop = isset($_POST['nop']) ? trim($_POST['nop']) : '';
$tgl_jatuh_tempo = isset($_POST['tgl_jatuh_tempo']) ? trim($_POST['tgl_jatuh_tempo']) : '';

if ($nop == '' || $tgl_jatuh_tempo == '') {
    echo "<script>alert('NOP dan Tanggal Jatuh Tempo wajib diisi!'); window.history.back();</script>";
    exit;
}

// Cek apakah NOP valid
$sql = "SELECT * FROM dataobjek o JOIN datasubjek s ON o.ktp_subjek = s.ktp_subjek WHERE o.nop = '$nop'";
$res = $link->query($sql);

if (!$res || $res->num_rows !== 1) {
    echo "<script>alert('NOP tidak ditemukan atau data tidak lengkap'); window.history.back();</script>";
    exit;
}

$data = $res->fetch_assoc();
$nama_subjek = $data['nama_subjek'];
$pokok = $data['njop_dasar'] * 0.001;

// Hitung denda
$tgl_jatuh = DateTime::createFromFormat('Y-m-d', $tgl_jatuh_tempo);
$tgl_now = new DateTime();

$diff = $tgl_jatuh->diff($tgl_now);
$jumlah_bulan = $diff->m + ($diff->y * 12);

if ($tgl_now < $tgl_jatuh) {
    $jumlah_bulan = 0;
}

$denda = 0.02 * $pokok * $jumlah_bulan;
$jumlah_tagihan = $pokok + $denda;
$status_kelunasan = "Belum Lunas";
$tahun_pajak = $tgl_jatuh->format('Y');

// Simpan tagihan
$sql = "INSERT INTO tagihan (
            nop, tahun_pajak, id_pembayaran, nama_subjek, pokok, denda, jumlah_tagihan, 
            tgl_jatuh_tempo, jumlah_bulan, status_kelunasan
        ) VALUES (
            '$nop', '$tahun_pajak', NULL, '$nama_subjek', '$pokok', '$denda', '$jumlah_tagihan', 
            '{$tgl_jatuh->format('Y-m-d')}', '$jumlah_bulan', '$status_kelunasan'
        )";

if (!$link->query($sql)) {
    echo "<script>alert('Gagal menambah data tagihan: " . addslashes($link->error) . "'); window.history.back();</script>";
    exit;
}

echo "<script>alert('Berhasil menambah data tagihan'); window.location.href = '../admin/daftar-tagihan.php';</script>";
?>
