<?php
session_start();
include "libs/koneksi.php";
$link = koneksi_db();

$nop = isset($_GET['nop']) ? $_GET['nop'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Disyanjak Kec Lubai</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
</head>
<body class="homepage">
    <header id="header">
        <!-- Navigasi (jika ada) -->
    </header>

    <section id="contact-page">
        <div class="container" style="min-height:420px;">
            <div class="center">
                <h2>Cek Tagihan</h2>
                <p class="lead">Pajak Bumi dan Bangunan</p>
            </div>

            <?php
            if (empty($nop)) {
                echo "<div class='alert alert-warning text-center'>NOP tidak tersedia.</div>";
            } else {
                $sql = "SELECT * FROM tagihan WHERE nop = '$nop'";
                $result = mysqli_query($link, $sql);

                if (!$result) {
                    echo "<div class='alert alert-danger text-center'>Query error: " . mysqli_error($link) . "</div>";
                } elseif (mysqli_num_rows($result) == 0) {
                    echo "<div class='alert alert-info text-center'><h4>Tagihan tidak ditemukan untuk NOP: <strong>$nop</strong></h4></div>";
                } else {
                    echo "<div class='table-responsive'>";
                    echo "<table class='table table-bordered table-striped'>";
                    echo "<thead class='thead-dark'>";
                    echo "<tr>
                    <th>ID Tagihan</th>
                    <th>NOP</th>
                    <th>Tahun</th>
                    <th>Jumlah Tagihan</th>
                    <th>Status</th>
                    </tr>";
                    echo "</thead><tbody>";

                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['id_tagihan']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['nop']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['tahun_pajak']) . "</td>";
                        echo "<td>Rp " . number_format($row['jumlah_tagihan'], 0, ',', '.') . "</td>";
                        echo "<td>" . htmlspecialchars($row['status_kelunasan']) . "</td>";
                        echo "</tr>";
                    }

                    echo "</tbody></table></div>";
                }
            }
            ?>

            <!-- Tombol kembali -->
            <div class="text-center mt-4">
                <a href="index.php" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Kembali ke Beranda</a>
            </div>
        </div>
    </section>

    <footer id="footer" class="midnight-blue">
        <div class="container text-center">
            &copy; 2016 <a target="_blank">Pajak Bumi Bangunan</a>.
        </div>
    </footer>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
